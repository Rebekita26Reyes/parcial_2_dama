package net.tareas.Parcial2.clases;

public class Configuraciones {
    public String urlWebServices;

    public Configuraciones(){
        this.urlWebServices = "http://192.168.1.72/PARCIAL/webservices02.php";
    }
}
