package net.tareas.Parcial2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import net.tareas.Parcial2.clases.Configuraciones;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Calendar;
public class RegistrarTarea extends AppCompatActivity implements View.OnClickListener {
    EditText nombre_tarea, descripcion, efecha, ehora;
    private int hora, minutos;
    CheckBox checkBoxPendiente, checkBoxCompletada;
    Button botonAgregar, botonRegresar, bfecha, bhora;
    Configuraciones objConfiguracion = new Configuraciones();
    String URL = objConfiguracion.urlWebServices;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_tarea);


        nombre_tarea = findViewById(R.id.txtNombreTareaEditar);
        descripcion = findViewById(R.id.txtDescripcionEditar);
        efecha = findViewById(R.id.efechaEditar);
        ehora = findViewById(R.id.ehoraEditar);
        bfecha = findViewById(R.id.bfecha);
        bhora = findViewById(R.id.bhora);
        bfecha.setOnClickListener(this);
        bhora.setOnClickListener(this);

        checkBoxPendiente = findViewById(R.id.c);
        checkBoxCompletada = findViewById(R.id.checkBoxCompletadaEditar);

        botonAgregar = findViewById(R.id.btnGuardarTareaEditar);
        botonRegresar = findViewById(R.id.btnRegresarEditar);


        //Evento (CLICK)
        botonAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Registrar
                registrar();
            }
        });

        botonRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Regresar
                regresar();
            }
        });
    }

    private void regresar(){
        Intent actividad = new Intent(RegistrarTarea.this,MainActivity.class);
        startActivity(actividad);
        RegistrarTarea.this.finish();
    }

    private void registrar(){
        try{
            RequestQueue objetoPeticion = Volley.newRequestQueue(RegistrarTarea.this);
            StringRequest peticion = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try{
                        JSONObject objJSONResultado = new JSONObject(response.toString());
                        String estado = objJSONResultado.getString("estado");
                        if(estado.equals("1")){
                            Toast.makeText(RegistrarTarea.this, "Tarea  Registrada con exito", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(RegistrarTarea.this, "Error: "+ estado, Toast.LENGTH_SHORT).show();
                        }

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(RegistrarTarea.this, "Error: "+ error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }){
                @Override
                protected Map<String,String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String,String>();
                    params.put("accion","registrar");
                    params.put("nombre_tarea",nombre_tarea.getText().toString());
                    params.put("descripcion",descripcion.getText().toString());
                    params.put("fecha",efecha.getText().toString());
                    params.put("hora",ehora.getText().toString());

                    StringBuilder resultado=new StringBuilder();
                    if (checkBoxPendiente.isChecked()){
                          resultado.append("\nPendiente");
                        params.put("estatus",checkBoxPendiente.getText().toString());

                    }if(checkBoxCompletada.isChecked()){
                        resultado.append("\nCompletada");
                        params.put("estatus",checkBoxCompletada.getText().toString());
                    }


                    return params;
                }
            };

            objetoPeticion.add(peticion);
        }catch (Exception error){
            Toast.makeText(RegistrarTarea.this, "Error en tiempo de ejecucion: "+ error.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onClick(View view) {
        if (view==bfecha){
            Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int dayOfMonth = c.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    efecha.setText(year+"-"+(month+1)+"-"+dayOfMonth);
                }
            }, year, month, dayOfMonth);

            datePickerDialog.show();

        }
        if(view==bhora){
            final Calendar c= Calendar.getInstance();
            hora=c.get(Calendar.HOUR_OF_DAY);
            minutos=c.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    ehora.setText(hourOfDay+":"+minute);
                }
            },hora,minutos,false);
            timePickerDialog.show();
        }
    }
}
