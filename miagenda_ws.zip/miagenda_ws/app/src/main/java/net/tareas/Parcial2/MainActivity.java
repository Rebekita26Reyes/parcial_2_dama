package net.tareas.Parcial2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import net.tareas.Parcial2.clases.Configuraciones;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    Button botonAgregar, botonBuscar, btnpendientes, btnfinalizadas, btntodas;

    ListView listaTareas;
    EditText txtCriterio;
    Configuraciones objConfiguracion = new Configuraciones();
    String URL = objConfiguracion.urlWebServices;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        botonAgregar = findViewById(R.id.btnAgregar);
        botonAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ventana = new Intent(MainActivity.this, RegistrarTarea.class);
                startActivity(ventana);
            }
        });

        txtCriterio = findViewById(R.id.txtCriterio);
        listaTareas = findViewById(R.id.lvTarea);

        btnpendientes = findViewById(R.id.btnpendientes);
        btnfinalizadas = findViewById(R.id.btnfinalizadas);
        btntodas = findViewById(R.id.btntodas);

        botonBuscar = findViewById(R.id.btnBuscar);
        botonBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llenarLista();
            }
        });

        btnfinalizadas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrartareasfinalizadas();
            }
        });

        btnpendientes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrartareaspendientes();
            }
        });

        btntodas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrartareastodas();
            }
        });

    }
    public  void mostrartareaspendientes(){
        RequestQueue objetoPeticion = Volley.newRequestQueue(MainActivity.this);
        StringRequest peticion = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try{
                    JSONObject objJSONResultado = new JSONObject(response.toString());
                    JSONArray aDatosResultado = objJSONResultado.getJSONArray("resultado");

                    AdaptadorListaTareas miAdaptador = new AdaptadorListaTareas();
                    miAdaptador.arregloDatos = aDatosResultado;
                    listaTareas.setAdapter(miAdaptador);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Error: "+ error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String,String> getParams() throws AuthFailureError{
                Map<String,String> params = new HashMap<String,String>();
                params.put("accion","mostrartareaspendientes");
                return params;
            }
        };

        objetoPeticion.add(peticion);


    }

    public  void mostrartareasfinalizadas(){
        RequestQueue objetoPeticion = Volley.newRequestQueue(MainActivity.this);
        StringRequest peticion = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try{
                    JSONObject objJSONResultado = new JSONObject(response.toString());
                    JSONArray aDatosResultado = objJSONResultado.getJSONArray("resultado");

                    AdaptadorListaTareas miAdaptador = new AdaptadorListaTareas();
                    miAdaptador.arregloDatos = aDatosResultado;
                    listaTareas.setAdapter(miAdaptador);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Error: "+ error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String,String> getParams() throws AuthFailureError{
                Map<String,String> params = new HashMap<String,String>();
                params.put("accion","mostrartareasfinalizadas");
                return params;
            }
        };

        objetoPeticion.add(peticion);


    }
    public  void mostrartareastodas(){
        RequestQueue objetoPeticion = Volley.newRequestQueue(MainActivity.this);
        StringRequest peticion = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try{
                    JSONObject objJSONResultado = new JSONObject(response.toString());
                    JSONArray aDatosResultado = objJSONResultado.getJSONArray("resultado");

                    AdaptadorListaTareas miAdaptador = new AdaptadorListaTareas();
                    miAdaptador.arregloDatos = aDatosResultado;
                    listaTareas.setAdapter(miAdaptador);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Error: "+ error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String,String> getParams() throws AuthFailureError{
                Map<String,String> params = new HashMap<String,String>();
                params.put("accion","mostrartareastodas");
                return params;
            }
        };

        objetoPeticion.add(peticion);


    }

    @Override
    protected void onResume() {
        super.onResume();
        try{
            llenarLista();
        }catch (Exception error){
            Toast.makeText(MainActivity.this, "Error: "+ error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void llenarLista(){
        final String criterio = txtCriterio.getText().toString();
        RequestQueue objetoPeticion = Volley.newRequestQueue(MainActivity.this);
        StringRequest peticion = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try{
                   JSONObject objJSONResultado = new JSONObject(response.toString());
                   JSONArray aDatosResultado = objJSONResultado.getJSONArray("resultado");

                   AdaptadorListaTareas miAdaptador = new AdaptadorListaTareas();
                   miAdaptador.arregloDatos = aDatosResultado;
                   listaTareas.setAdapter(miAdaptador);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Error: "+ error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
          @Override
          protected Map<String,String> getParams() throws AuthFailureError{
              Map<String,String> params = new HashMap<String,String>();
              params.put("accion","listar_tareas");
              params.put("filtro",criterio);
              return params;
          }
        };

        objetoPeticion.add(peticion);


    }

    class AdaptadorListaTareas extends BaseAdapter{
        public JSONArray arregloDatos;

        @Override
        public int getCount() {
            return arregloDatos.length();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {
            v = getLayoutInflater().inflate(R.layout.fila_contactos,null);
            TextView txtTarea = v.findViewById(R.id.tvfilatarea);
            TextView txtStatus = v.findViewById(R.id.tvfilaStatus);
            Button btnVer = v.findViewById(R.id.btnVerTarea);

            JSONObject objJSON = null;
            try{
                objJSON = arregloDatos.getJSONObject(position);
                final String id_tarea, nombre_tarea, descripcion, fecha, hora, estatus;
                id_tarea = objJSON.getString("id_tarea");
                nombre_tarea = objJSON.getString("nombre_tarea");
                descripcion = objJSON.getString("descripcion");
                fecha = objJSON.getString("fecha");
                hora = objJSON.getString("hora");
                estatus = objJSON.getString("estatus");

                txtTarea.setText(nombre_tarea);
                txtStatus.setText(estatus);;

                btnVer.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent ventanaModificar = new Intent(MainActivity.this, ModificarTarea.class);
                        ventanaModificar.putExtra("id_tarea", id_tarea);
                        ventanaModificar.putExtra("nombre_tarea", nombre_tarea);
                        ventanaModificar.putExtra("descripcion", descripcion);
                        ventanaModificar.putExtra("fecha", fecha);
                        ventanaModificar.putExtra("hora", hora);
                        ventanaModificar.putExtra("estatus", estatus);
                        startActivity(ventanaModificar);
                    }
                });

            }catch (JSONException e){
                e.printStackTrace();
            }
            return v;
        }
    }


}
