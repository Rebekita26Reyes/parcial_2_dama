package net.tareas.Parcial2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import net.tareas.Parcial2.clases.Configuraciones;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class ModificarTarea extends AppCompatActivity implements View.OnClickListener {

    EditText nombre_tarea;
    EditText descripcion;
    EditText efechaEditar;
    EditText ehoraEditar;
    private int hora, minutos;
    private RadioGroup radioGroupEstatus;
    private CheckBox checkBoxPendienteEditar;
    private CheckBox checkBoxCompletadaEditar;


    Button botonAgregar, botonRegresar, botonEliminar, mfecha, mhora;
    String id_tarea, nombredetarea, descripciondetarea, fechadetarea, horadetarea, estatusdetarea ;

    Configuraciones objConfiguracion = new Configuraciones();
    String URL = objConfiguracion.urlWebServices;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_tarea);


        nombre_tarea = findViewById(R.id.txtNombreTareaEditar);
        descripcion = findViewById(R.id.txtDescripcionEditar);
        efechaEditar = findViewById(R.id.efechaEditar);
        ehoraEditar = findViewById(R.id.ehoraEditar);
        mfecha = findViewById(R.id.mfecha);
        mhora = findViewById(R.id.mhora);
        checkBoxPendienteEditar = findViewById(R.id.checkBoxPendienteEditar);
        checkBoxCompletadaEditar = findViewById(R.id.checkBoxCompletadaEditar);

        botonAgregar = findViewById(R.id.btnGuardarTareaEditar);
        botonRegresar = findViewById(R.id.btnRegresarEditar);
        botonEliminar = findViewById(R.id.btnEliminarEditar);
        mfecha.setOnClickListener(this);
        mhora.setOnClickListener(this);
        botonAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                modificar();
            }
        });

        botonRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                regresar();
            }
        });

        botonEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eliminar();
            }
        });
    }

    private void modificar() {
        try {
            RequestQueue objetoPeticion = Volley.newRequestQueue(ModificarTarea.this);
            StringRequest peticion = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject objJSONResultado = new JSONObject(response.toString());
                        String estado = objJSONResultado.getString("estado");
                        if (estado.equals("1")) {
                            Toast.makeText(ModificarTarea.this, "Tarea Modificada con exito", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ModificarTarea.this, "Error: " + estado, Toast.LENGTH_SHORT).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(ModificarTarea.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    final Map<String, String> params = new HashMap<String, String>();
                    params.put("accion", "modificar");
                    params.put("id_tarea", id_tarea);
                    params.put("nombre_tarea", nombre_tarea.getText().toString());
                    params.put("descripcion", descripcion.getText().toString());
                    params.put("fecha", efechaEditar.getText().toString());
                    params.put("hora", ehoraEditar.getText().toString());
                    StringBuilder resultado = new StringBuilder();
                    if (checkBoxPendienteEditar.isChecked()){
                        resultado.append("\nPendiente");
                        params.put("estatus",checkBoxPendienteEditar.getText().toString());

                    }if(checkBoxCompletadaEditar.isChecked()){
                        resultado.append("\nCompletada");
                        params.put("estatus",checkBoxCompletadaEditar.getText().toString());
                    }

                    return params;
                }
            };

            objetoPeticion.add(peticion);
        } catch (Exception error) {
            Toast.makeText(ModificarTarea.this, "Error en tiempo de ejecucion: " + error.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void regresar() {
        Intent actividad = new Intent(ModificarTarea.this, MainActivity.class);
        startActivity(actividad);
        ModificarTarea.this.finish();
    }

    private void eliminar() {
        try {
            RequestQueue objetoPeticion = Volley.newRequestQueue(ModificarTarea.this);
            StringRequest peticion = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject objJSONResultado = new JSONObject(response.toString());
                        String estado = objJSONResultado.getString("estado");
                        if (estado.equals("1")) {
                            Toast.makeText(ModificarTarea.this, "Tarea Eliminada con exito", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ModificarTarea.this, "Error: " + estado, Toast.LENGTH_SHORT).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(ModificarTarea.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("accion", "eliminar");
                    params.put("id_tarea", id_tarea);
                    return params;
                }
            };

            objetoPeticion.add(peticion);
        } catch (Exception error) {
            Toast.makeText(ModificarTarea.this, "Error en tiempo de ejecucion: " + error.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Bundle valoresAdicionales = getIntent().getExtras();
        if (valoresAdicionales == null) {
            Toast.makeText(ModificarTarea.this, "Debe enviar un ID de tarea", Toast.LENGTH_SHORT).show();
            id_tarea = "";
            regresar();
        } else {
            id_tarea = valoresAdicionales.getString("id_tarea");
            nombredetarea = valoresAdicionales.getString("nombre_tarea");
            descripciondetarea = valoresAdicionales.getString("descripcion");
            fechadetarea = valoresAdicionales.getString("fecha");
            horadetarea = valoresAdicionales.getString("hora");
            estatusdetarea = valoresAdicionales.getString("estatus");


        }

        verTarea();
    }


    private void verTarea() {
        nombre_tarea.setText(nombredetarea);
        descripcion.setText(descripciondetarea);
        efechaEditar.setText(fechadetarea);
        ehoraEditar.setText(horadetarea);

        if (estatusdetarea != null) {
            if (estatusdetarea.contains("Pendiente")) {
                checkBoxPendienteEditar.setChecked(true);
            } else {
                checkBoxPendienteEditar.setChecked(false);
            }

            if (estatusdetarea.contains("Completada")) {
                checkBoxCompletadaEditar.setChecked(true);
            } else {
                checkBoxCompletadaEditar.setChecked(false);
            }
        }
    }

    @Override
    public void onClick(View view) {
        if (view==mfecha){
            Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int dayOfMonth = c.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    efechaEditar.setText(year+"-"+(month+1)+"-"+dayOfMonth);
                }
            }, year, month, dayOfMonth);

            datePickerDialog.show();

        }
        if(view==mhora){
            final Calendar c= Calendar.getInstance();
            hora=c.get(Calendar.HOUR_OF_DAY);
            minutos=c.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    ehoraEditar.setText(hourOfDay+":"+minute);
                }
            },hora,minutos,false);
            timePickerDialog.show();
        }
    }
}